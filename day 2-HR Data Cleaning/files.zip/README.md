# 🧹 Day 02 — Data Cleaning & Preprocessing
> **30 Days of Machine Learning**

## 📌 What This Project Covers
- ✅ Duplicate detection & removal
- ✅ String cleaning (names, gender, department, city, education)
- ✅ Date parsing across multiple messy formats
- ✅ Missing value imputation (median, group median, mode)
- ✅ Outlier detection & removal (IQR + Z-score)
- ✅ Categorical encoding (binary, ordinal, one-hot)

## 📁 Files
| File | Description |
|------|-------------|
| `hr_data_cleaning.ipynb` | Main notebook — run this! |
| `messy_hr_data.csv` | Raw messy input (500 rows) |
| `clean_hr_data.csv` | Cleaned output (426 rows) |
| `encoded_hr_data.csv` | ML-ready encoded output (28 cols) |
| `*.png` | Before/After visualizations |

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib seaborn scikit-learn scipy jupyter
jupyter notebook hr_data_cleaning.ipynb
```

## 📊 Key Results
- **500 → 426 rows** after removing duplicates + outliers
- **12 → 15 columns** (new: join_year, join_month, tenure_years)
- **236 missing values** handled via smart imputation
- **5 categorical columns** standardized & encoded
- **Clean dataset** ready for Day 3 ML modeling!

## 🛠️ Tech Stack
`Python` `Pandas` `NumPy` `Matplotlib` `Seaborn` `Scipy` `Scikit-learn`

---
*Day 2/30 — #30DaysOfML 🚀*
